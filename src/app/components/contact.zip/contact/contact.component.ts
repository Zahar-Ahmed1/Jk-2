import { NgStyle } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { CloudinaryModule } from '@cloudinary/ng';
import { Cloudinary } from "@cloudinary/url-gen";
import { fill } from "@cloudinary/url-gen/actions/resize";
import { Router, NavigationStart, NavigationEnd } from '@angular/router';


@Component({
  selector: 'app-contact',
  imports: [NgStyle,CloudinaryModule],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css'
})
export class ContactComponent implements OnInit {
  private scrollPositions: { [url: string]: number } = {};
  private currentUrl: string = '';
  email: string = 'achrafnajouwork@gmail.com';

  img: any;
   constructor(private router: Router) {
      this.router.events.subscribe(event => {
        if (event instanceof NavigationStart) {
          // Sauvegarde la position de scroll actuelle avant de quitter la page
          this.scrollPositions[this.currentUrl] = window.scrollY;
        } else if (event instanceof NavigationEnd) {
          this.currentUrl = event.urlAfterRedirects;
  
          // Restaure la position de scroll de la page
          setTimeout(() => {
            window.scrollTo(0, this.scrollPositions[this.currentUrl] || 0);
          }, 100);
        }
      });
    }
  ngOnInit() {

    // Create a Cloudinary instance and set your cloud name.
    const cld = new Cloudinary({
      cloud: {
        cloudName: 'dxtlsrtoq'
      }
    });
    // Instantiate a CloudinaryImage object for the image with the public ID, 'docs/models'.
    this.img = cld.image('dpzuuhbfievxifvqn4v5');

    // Resize to 250 x 250 pixels using the 'fill' crop mode.
    this.img.resize(fill().width(1500).height(950));
  }

}
